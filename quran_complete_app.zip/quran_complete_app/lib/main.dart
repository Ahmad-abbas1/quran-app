import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'القرآن الكريم',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF0E5C3F),
        scaffoldBackgroundColor: const Color(0xFFFAF7F0),
        fontFamily: 'Amiri',
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0E5C3F),
          brightness: Brightness.light,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// شاشة البداية
class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0E5C3F), Color(0xFF0F6E56)],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 40),
                  const Text(
                    '🤍',
                    style: TextStyle(fontSize: 100),
                  ),
                  const SizedBox(height: 30),
                  const Text(
                    'القرآن الكريم',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFFAF7F0),
                    ),
                  ),
                  const SizedBox(height: 15),
                  const Text(
                    'مع الأحاديث الصحيحة والأدعية النبوية',
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFFC9A24A),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 60),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: const Color(0xFFC9A24A),
                        width: 2,
                      ),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          '🌿 الإهداء 🌿',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFC9A24A),
                          ),
                        ),
                        const SizedBox(height: 15),
                        const Text(
                          'هذا التطبيق صدقة جارية عن روح الحاجة\nرتيبة سعيد قط اللبن\nرحمها الله وأسكنها فسيح جناته',
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xFFFAF7F0),
                            height: 1.8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 15),
                        const Text(
                          'كل من قرأ القرآن والسنة في هذا التطبيق\nأجره وأجرها في ميزان حسناتهما بإذن الله',
                          style: TextStyle(
                            fontSize: 12,
                            color: Color(0xFFFAF7F0),
                            height: 1.8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 15),
                        const Text(
                          '💚',
                          style: TextStyle(fontSize: 24),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 60),
                  const Text(
                    'الإصدار 2.0.0',
                    style: TextStyle(
                      fontSize: 12,
                      color: Color(0xFFC9A24A),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// الشاشة الرئيسية
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('القرآن الكريم'),
        centerTitle: true,
        backgroundColor: const Color(0xFF0E5C3F),
        elevation: 0,
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          const QuranScreen(),
          const HadithScreen(),
          const DuaScreen(),
          const FavoritesScreen(),
          const SettingsScreen(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: const Color(0xFF0E5C3F),
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.menu_book),
            label: 'القرآن',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.library_books),
            label: 'الأحاديث',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'الأدعية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: 'المفضلات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'الإعدادات',
          ),
        ],
      ),
    );
  }
}

// شاشة القرآن
class QuranScreen extends StatelessWidget {
  const QuranScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSectionHeader('القرآن الكريم'),
        const SizedBox(height: 20),
        _buildFeatureCard(
          'context',
          'قراءة السور',
          '114 سورة كاملة',
          Icons.description,
        ),
        const SizedBox(height: 15),
        _buildFeatureCard(
          'context',
          'استماع للقرآن',
          '8 قراء محترفين',
          Icons.music_note,
        ),
        const SizedBox(height: 15),
        _buildFeatureCard(
          'context',
          'البحث',
          'ابحث عن أي آية',
          Icons.search,
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.bold,
        color: Color(0xFF0E5C3F),
      ),
    );
  }

  Widget _buildFeatureCard(
    BuildContext context,
    String title,
    String subtitle,
    IconData icon,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border(
          right: BorderSide(
            color: const Color(0xFFC9A24A),
            width: 4,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF0E5C3F), size: 32),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0E5C3F),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF888780),
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios, size: 16),
        ],
      ),
    );
  }
}

// شاشة الأحاديث
class HadithScreen extends StatelessWidget {
  const HadithScreen({Key? key}) : super(key: key);

  final List<Map<String, String>> hadiths = const [
    {
      'title': 'الحديث الأول',
      'text': 'الأعمال بالنيات وإنما لكل امرئ ما نوى',
      'source': 'صحيح البخاري',
    },
    {
      'title': 'الحديث الثاني',
      'text': 'من يرد الله به خيراً يفقهه في الدين',
      'source': 'صحيح مسلم',
    },
    {
      'title': 'الحديث الثالث',
      'text': 'خيركم أحسنكم أخلاقاً',
      'source': 'صحيح البخاري',
    },
    {
      'title': 'الحديث الرابع',
      'text': 'لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه',
      'source': 'صحيح مسلم',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'الأحاديث الصحيحة',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0E5C3F),
          ),
        ),
        const SizedBox(height: 20),
        ...hadiths.map((hadith) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border(
                  right: BorderSide(
                    color: const Color(0xFF0E5C3F),
                    width: 4,
                  ),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    hadith['title'] ?? '',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFC9A24A),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    hadith['text'] ?? '',
                    style: const TextStyle(
                      fontSize: 16,
                      height: 1.8,
                      color: Color(0xFF1A1F1B),
                    ),
                    textAlign: TextAlign.right,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    hadith['source'] ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF888780),
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ],
    );
  }
}

// شاشة الأدعية
class DuaScreen extends StatelessWidget {
  const DuaScreen({Key? key}) : super(key: key);

  final List<Map<String, String>> duas = const [
    {
      'title': 'دعاء الصباح',
      'text': 'اللهم بك أصبحنا وبك أمسينا وبك نحيا وبك نموت وإليك النشور',
      'category': 'أدعية الصباح والمساء',
    },
    {
      'title': 'دعاء الاستيقاظ',
      'text': 'الحمد لله الذي أحيانا بعدما أماتنا وإليه النشور',
      'category': 'أدعية النوم والاستيقاظ',
    },
    {
      'title': 'دعاء الطعام',
      'text': 'بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم',
      'category': 'أدعية الأكل والشرب',
    },
    {
      'title': 'دعاء الكرب',
      'text': 'لا إله إلا الله العظيم الحليم، لا إله إلا الله رب العرش الكريم',
      'category': 'أدعية الكرب والضيق',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'الأدعية النبوية',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0E5C3F),
          ),
        ),
        const SizedBox(height: 20),
        ...duas.map((dua) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFFFBF4E1),
                    const Color(0xFFFFFFFF),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border(
                  right: BorderSide(
                    color: const Color(0xFFC9A24A),
                    width: 4,
                  ),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    dua['title'] ?? '',
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0E5C3F),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    dua['text'] ?? '',
                    style: const TextStyle(
                      fontSize: 16,
                      height: 1.8,
                      color: Color(0xFF1A1F1B),
                    ),
                    textAlign: TextAlign.right,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    dua['category'] ?? '',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFFC9A24A),
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFF3E5F5),
                const Color(0xFFE3F2FD),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFF6A1B9A),
              width: 2,
            ),
          ),
          child: Column(
            children: [
              const Text(
                '🤲 دعاء للحاجة رتيبة 🤲',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF6A1B9A),
                  height: 1.8,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 15),
              const Text(
                'اللهم اغفر لها وارحمها وعافها واعفُ عنها وأكرم نزلها ووسّع مدخلها واغسلها بالماء والثلج والبرد ونقّها من الخطايا كما يُنقّى الثوب الأبيض من الدنس وأبدلها داراً خيراً من دارها وأهلاً خيراً من أهلها',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF1A1F1B),
                  height: 1.8,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 15),
              const Text(
                'اللهم اجعل القرآن ربيع قلبها في قبرها ونور بصرها وشافعاً لها يوم العرض عليك',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF6A1B9A),
                  height: 1.8,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              const Text(
                'آمين آمين يا رب العالمين 💚',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF6A1B9A),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// شاشة المفضلات
class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.star_outline,
              size: 80,
              color: Color(0xFFC9A24A),
            ),
            const SizedBox(height: 20),
            const Text(
              'المفضلات',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0E5C3F),
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'احفظ سورك وأحاديثك وأدعيتك المفضلة هنا',
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF888780),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// شاشة الإعدادات
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'الإعدادات',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0E5C3F),
          ),
        ),
        const SizedBox(height: 30),
        _buildSettingItem(
          'القارئ',
          'اختر القارئ المفضل',
          Icons.person,
        ),
        const SizedBox(height: 15),
        _buildSettingItem(
          'مواقيت الصلاة',
          'طريقة الحساب والموقع',
          Icons.access_time,
        ),
        const SizedBox(height: 15),
        _buildSettingItem(
          'الإشعارات',
          'تفعيل إشعارات الأذان',
          Icons.notifications,
        ),
        const SizedBox(height: 15),
        _buildSettingItem(
          'عن التطبيق',
          'الإصدار والمعلومات',
          Icons.info,
        ),
        const SizedBox(height: 40),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFFFBF4E1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFFC9A24A),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text(
                'عن التطبيق',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0E5C3F),
                ),
              ),
              const SizedBox(height: 15),
              const Text(
                'القرآن الكريم - الإصدار 2.0.0',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF1A1F1B),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'تطبيق إسلامي شامل يجمع بين القرآن الكريم والأحاديث الصحيحة والأدعية النبوية',
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xFF888780),
                  height: 1.6,
                ),
                textAlign: TextAlign.right,
              ),
              const SizedBox(height: 15),
              const Text(
                '💚 صدقة جارية عن الحاجة رتيبة سعيد قط اللبن رحمها الله 💚',
                style: TextStyle(
                  fontSize: 12,
                  color: Color(0xFF0E5C3F),
                  fontWeight: FontWeight.bold,
                  height: 1.6,
                ),
                textAlign: TextAlign.right,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSettingItem(String title, String subtitle, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border(
          right: BorderSide(
            color: const Color(0xFFC9A24A),
            width: 4,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF0E5C3F)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0E5C3F),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF888780),
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios, size: 16),
        ],
      ),
    );
  }
}
